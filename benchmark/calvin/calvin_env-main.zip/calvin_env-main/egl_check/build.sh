g++  glad/egl.c glad/gl.c EGL_options.cpp -I glad/ -l dl -fPIC -o EGL_options.o
