# Which EGL device am I using?

This file provides to options to see which EGL device is being used:

```
bash build.sh 			    # compile c++ code
python list_egl_devices.py 	# run c++ code multiple times
python egl_python.py		# see what the pyOpenGL default option is
```
