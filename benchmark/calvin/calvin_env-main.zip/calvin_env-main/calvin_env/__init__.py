"""'VR Data Collection and Rendering
:copyright: 2019 by Oier Mees, Lukas Hermann, Wolfram Burgard
:license: GPLv3, see LICENSE for more details.
"""

__version__ = "0.0.1"
__project__ = "calvin_env"
__author__ = "Oier Mees, Lukas Hermann"
__license__ = "GPLv3"
__email__ = "meeso@informatik.uni-freiburg.de, hermannl@informatik.uni-freiburg.de,"
